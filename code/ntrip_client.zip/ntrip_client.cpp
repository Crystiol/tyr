#include <iostream>
#include <thread>
#include <chrono>
#include <mutex>
#include <vector>
#include <string>
#include <sstream>
#include <cmath>
#include <iomanip>
#include <fstream>
#include <cstring>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/tcp.h>

// -------------------- Base64 --------------------
std::string base64_encode(const std::string &in) {
    static const char tbl[] =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::string out;
    int val=0, valb=-6;
    for (unsigned char c : in) {
        val = (val<<8) + c;
        valb += 8;
        while (valb>=0) {
            out.push_back(tbl[(val>>valb)&0x3F]);
            valb -= 6;
        }
    }
    if (valb>-6) out.push_back(tbl[((val<<8)>>(valb+8))&0x3F]);
    while (out.size()%4) out.push_back('=');
    return out;
}

// -------------------- GNSS 数据 --------------------
struct GnssData {
    int hour, min, sec;
    double sec_fraction;
    double lat;
    double lon;
    double alt;
    int fix_quality;
    int num_sat;
    double hdop;
    double geoid_sep;
};

// 度转度分（高精度）
std::string deg2dms_precise(double deg) {
    int d = static_cast<int>(deg);
    double m = (deg - d) * 60.0;
    std::ostringstream oss;
    oss << std::setw(2) << std::setfill('0') << d
        << std::fixed << std::setprecision(7) << m;
    return oss.str();
}

void configureSocketOptions(int sock) {
    int flag = 1;
    setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, &flag, sizeof(flag));
    setsockopt(sock, SOL_SOCKET, SO_KEEPALIVE, &flag, sizeof(flag));

#ifdef TCP_KEEPIDLE
    int idle = 30, intvl = 10, cnt = 3;
    setsockopt(sock, IPPROTO_TCP, TCP_KEEPIDLE, &idle, sizeof(idle));
    setsockopt(sock, IPPROTO_TCP, TCP_KEEPINTVL, &intvl, sizeof(intvl));
    setsockopt(sock, IPPROTO_TCP, TCP_KEEPCNT, &cnt, sizeof(cnt));
#endif

    int rcvbuf = 64 * 1024;
    int sndbuf = 64 * 1024;
    setsockopt(sock, SOL_SOCKET, SO_RCVBUF, &rcvbuf, sizeof(rcvbuf));
    setsockopt(sock, SOL_SOCKET, SO_SNDBUF, &sndbuf, sizeof(sndbuf));
}

struct NTRIPStream {
    std::string mountpoint;
    std::string description;
    std::string format;
    std::string messages;
    std::string country;
    double latitude;
    double longitude;
    int altitude;
    int encryption;
    std::string caster;
    std::string operatorName;
    char refStationType;
    char networkRTK;
    int portOrID;
};

// 分割字符串，按分号分割
std::vector<std::string> split(const std::string &s, char delimiter) {
    std::vector<std::string> tokens;
    std::string token;
    std::istringstream tokenStream(s);
    while (std::getline(tokenStream, token, delimiter)) {
        tokens.push_back(token);
    }
    return tokens;
}

// 从 STR 行解析 NTRIPStream
NTRIPStream parseSTR(const std::string &line) {
    auto fields = split(line, ';');
    if (fields.size() < 18) {
        throw std::runtime_error("STR line字段不足");
    }

    NTRIPStream stream;
    stream.mountpoint      = fields[1];
    stream.description     = fields[2];
    stream.format          = fields[3];
    stream.messages        = fields[4];
    stream.country         = fields[8];
    stream.latitude        = fields[9].empty() ? 0 : std::stod(fields[9]);
    stream.longitude       = fields[10].empty() ? 0 : std::stod(fields[10]);
    stream.altitude        = fields[11].empty() ? 0 : std::stoi(fields[11]);
    stream.encryption      = fields[12].empty() ? 0 : std::stoi(fields[12]);
    stream.caster          = fields[13];
    stream.operatorName    = fields[14];
    stream.refStationType  = fields[15].empty() ? ' ' : fields[15][0];
    stream.networkRTK      = fields[16].empty() ? ' ' : fields[16][0];
    stream.portOrID        = std::stoi(fields[17]);
    return stream;
}

bool getsrctbl(const char* host, std::vector<NTRIPStream>& srctbl) {
    srctbl.clear();
    const int port = 2101;  // NTRIP caster 标准端口，硬编码

    // 步骤1: 解析地址
    struct addrinfo hints = {};
    struct addrinfo* res = nullptr;
    hints.ai_family = AF_UNSPEC;  // IPv4 或 IPv6
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_protocol = IPPROTO_TCP;

    int status = getaddrinfo(host, std::to_string(port).c_str(), &hints, &res);
    if (status != 0) {
        std::cerr << "getaddrinfo error: " << gai_strerror(status) << std::endl;
        return false;
    }

    int sockfd = -1;
    struct addrinfo* p = res;
    // 步骤2: 创建套接字并连接
    while (p != nullptr) {
        sockfd = socket(p->ai_family, p->ai_socktype, p->ai_protocol);
        if (sockfd == -1) {
            p = p->ai_next;
            continue;
        }

        configureSocketOptions(sockfd);

        if (connect(sockfd, p->ai_addr, p->ai_addrlen) == -1) {
            close(sockfd);
            p = p->ai_next;
            continue;
        }
        std::cerr << "连接成功" << std::endl;

        break;  // 连接成功
    }

    if (p == nullptr) {
        std::cerr << "Failed to connect to " << host << ":" << port << std::endl;
        freeaddrinfo(res);
        return false;
    }

    // 步骤3: 发送 NTRIP Source Table 请求
    std::string request = "GET / HTTP/1.0\r\nUser-Agent: NTRIP RTKLIB/2.4.3\r\nAccept: */*\r\nConnection: close\r\n\r\n";
    ssize_t sent = send(sockfd, request.c_str(), request.length(), 0);
    if (sent != static_cast<ssize_t>(request.length())) {
        std::cerr << "Send failed" << std::endl;
        close(sockfd);
        freeaddrinfo(res);
        return false;
    }
    std::cerr << "发送请求" << std::endl;

    // 步骤4: 接收响应
    char buffer[64*1024];
    std::string response;
    ssize_t bytes;

    while ((bytes = recv(sockfd, buffer, sizeof(buffer) - 1, 0)) > 0) {
        buffer[bytes] = '\0';
        response += buffer;
        std::cout << "接收字节:" << bytes << "字节" << std::endl;
    }

    if (bytes < 0) {
        std::cerr << "Recv failed" << std::endl;
    }

    close(sockfd);
    freeaddrinfo(res);

    if(response.empty())
        return !srctbl.empty();

    size_t pos = response.find("\r\n\r\n");
    if (pos == std::string::npos) {
        throw std::runtime_error("无法找到 HTTP 头与正文分隔符");
    }
    std::string body = response.substr(pos + 4);

    std::istringstream respStream(body);
    std::string line;

    while (std::getline(respStream, line)) {
        if (line.rfind("STR;", 0) == 0) {
            srctbl.push_back(parseSTR(line));
        }
    }

    return !srctbl.empty();
}

// 生成 GGA 字符串
std::string generateGGA(const GnssData &data) {
    char latH = (data.lat >= 0) ? 'N' : 'S';
    char lonH = (data.lon >= 0) ? 'E' : 'W';
    std::ostringstream gga;

    time_t now = time(nullptr);
    struct tm* tm_info = gmtime(&now);
    char time_str[20];
    sprintf(time_str, "%02d%02d%02d.51", tm_info->tm_hour, tm_info->tm_min, tm_info->tm_sec);

    // 时间 hhmmss.ss
    gga << "GPGGA,"
        << std::setw(2) << std::setfill('0') << tm_info->tm_hour
        << std::setw(2) << std::setfill('0') << tm_info->tm_min
        << std::fixed << std::setprecision(2)
        << std::setw(5) << std::setfill('0') << tm_info->tm_sec
        << ",";

    // 纬度
    gga << deg2dms_precise(std::fabs(data.lat)) << "," << latH << ",";

    // 经度
    gga << deg2dms_precise(std::fabs(data.lon)) << "," << lonH << ",";

    // 定位质量、卫星数、HDOP
    gga << data.fix_quality << ","
        << std::setw(2) << std::setfill('0') << data.num_sat << ","
        << std::fixed << std::setprecision(1) << data.hdop << ",";

    // 高程及单位
    gga << std::fixed << std::setprecision(3) << data.alt << ",M,";
    gga << std::fixed << std::setprecision(3) << data.geoid_sep << ",M,0.0,";

    // 校验和
    std::string s = gga.str();
    unsigned char checksum = 0;
    for (char c : s) checksum ^= c;

    std::ostringstream full;
    full << "$" << s << "*"
         << std::uppercase << std::hex
         << std::setw(2) << std::setfill('0') << (int)checksum
         << "\r\n";

    return full.str();
}

// -------------------- NTRIP Client --------------------
class NtripClient {
public:
    NtripClient(const std::string &host, int port, const std::string &mount,
                const std::string &user="", const std::string &passwd="")
        : host_(host), port_(port), mountpoint_(mount),
        user_(user), passwd_(passwd), sock_(-1), stop_flag_(false) {}

    void addOutput(std::ostream* out) {
        std::lock_guard<std::mutex> lock(out_mtx_);
        outputs_.push_back(out);
    }

    void setGGAData(GnssData data, int interval_ms=1000) {
        gga_data_ = data;
        gga_interval_ = interval_ms;
    }

    void start() {
        stop_flag_ = false;
        connectCaster();
        recv_thread_ = std::thread(&NtripClient::recvLoop, this);
        gga_thread_ = std::thread(&NtripClient::ggaLoop, this);
    }

    void stop() {
        stop_flag_ = true;
        {
            std::lock_guard<std::mutex> lock(sock_mtx_);
            if (sock_ >= 0) {
                shutdown(sock_, SHUT_RDWR);
                close(sock_);
                sock_ = -1;
            }
        }
        if (recv_thread_.joinable()) recv_thread_.join();
        if (gga_thread_.joinable()) gga_thread_.join();
    }

private:
    // 互斥锁：输出与 socket 各自独立
    std::mutex out_mtx_;
    std::mutex sock_mtx_;

    void connectCaster() {
        while (!stop_flag_) {
            int newsock = socket(AF_INET, SOCK_STREAM, 0);
            if (newsock < 0) {
                perror("socket");
                std::this_thread::sleep_for(std::chrono::seconds(1));
                continue;
            }

            configureSocketOptions(newsock);

            struct hostent* he = gethostbyname(host_.c_str());
            if (!he) {
                close(newsock);
                std::this_thread::sleep_for(std::chrono::seconds(1));
                continue;
            }

            struct sockaddr_in addr{};
            addr.sin_family = AF_INET;
            addr.sin_port = htons(port_);
            memcpy(&addr.sin_addr, he->h_addr, he->h_length);

            if (::connect(newsock, (sockaddr*)&addr, sizeof(addr)) < 0) {
                perror("connect");
                close(newsock);
                std::this_thread::sleep_for(std::chrono::seconds(1));
                continue;
            }

            std::cerr << "连接成功" << std::endl;

            {
                std::lock_guard<std::mutex> lock(sock_mtx_);
                if (sock_ >= 0) close(sock_);
                sock_ = newsock;
            }

            sendRequest();
            break;
        }
    }

    void sendRequest() {
        std::ostringstream oss;
        oss << "GET /" << mountpoint_ << " HTTP/1.0\r\n"
            << "User-Agent: NTRIP RTKLIB/2.4.3\r\n";
        if (!user_.empty()) {
            std::string auth = base64_encode(user_ + ":" + passwd_);
            oss << "Authorization: Basic " << auth << "\r\n";
        }
        oss << "\r\n";
        std::string req = oss.str();

        int curr_sock;
        {
            std::lock_guard<std::mutex> lock(sock_mtx_);
            curr_sock = sock_;
        }
        if (curr_sock >= 0)
            send(curr_sock, req.c_str(), req.size(), 0);

        std::cerr << "发送请求" << std::endl;
    }

    void recvLoop() {
        char buf[4096 * 64];
        ssize_t numbytes = 0;

        while (!stop_flag_) {
            int curr_sock;
            {
                std::lock_guard<std::mutex> lock(sock_mtx_);
                curr_sock = sock_;
            }

            if (curr_sock < 0) {
                std::this_thread::sleep_for(std::chrono::seconds(1));
                continue;
            }

            ssize_t n = recv(curr_sock, buf, sizeof(buf), 0);
            if (n <= 0) {
                std::cerr << "Connection lost. Reconnecting...\n";
                {
                    std::lock_guard<std::mutex> lock(sock_mtx_);
                    if (sock_ >= 0) {
                        shutdown(sock_, SHUT_RDWR);
                        close(sock_);
                        sock_ = -1;
                    }
                }
                std::this_thread::sleep_for(std::chrono::seconds(1));
                connectCaster();
                continue;
            }

            std::lock_guard<std::mutex> lock(out_mtx_);
            for (auto out : outputs_) {
                out->write(buf, n);
                out->flush();
                numbytes += n;
                // std::cout << "\r接收字节:" << numbytes << "字节" << std::flush;
                std::cout << "接收字节:" << numbytes << "字节" << std::endl;
            }
        }
    }

    void ggaLoop() {
        while (!stop_flag_) {
            std::string gga = generateGGA(gga_data_);
            int curr_sock;
            {
                std::lock_guard<std::mutex> lock(sock_mtx_);
                curr_sock = sock_;
            }

            if (curr_sock >= 0)
                send(curr_sock, gga.c_str(), gga.size(), 0);

            std::cerr << "发送GGA:" << gga << std::endl;
            std::this_thread::sleep_for(std::chrono::milliseconds(gga_interval_));
        }
    }

private:
    std::string host_, mountpoint_, user_, passwd_;
    int port_;
    int sock_;
    bool stop_flag_;
    std::vector<std::ostream*> outputs_;
    std::thread recv_thread_;
    std::thread gga_thread_;
    GnssData gga_data_;
    int gga_interval_{10000};
};

// -------------------- main --------------------
int main() {
    std::vector<NTRIPStream> srcs;
    if(getsrctbl("rtk2go.com", srcs)){
        for (const auto &s : srcs) {
            std::cout << s.mountpoint << ": " << s.description
                      << ", " << s.format
                      << ", Lat/Lon: " << s.latitude << "/" << s.longitude
                      << ", Port: " << s.portOrID << std::endl;
        }
    }

    NtripClient client("rtk2go.com", 2101, "ACAKO", "1041859295@qq.com", "none");

    std::ofstream fout("ntrip_output.rtcm", std::ios::binary);
    if (fout.is_open()) client.addOutput(&fout);

    GnssData gga;
    gga.hour=9; gga.min=1; gga.sec=55; gga.sec_fraction=0.51;
    gga.lat=-90.0; gga.lon=0.0; gga.alt=-6378107.466;
    gga.fix_quality=1; gga.num_sat=0; gga.hdop=1.0; gga.geoid_sep=-29.534;
    client.setGGAData(gga, 10000);

    client.start();

    std::this_thread::sleep_for(std::chrono::seconds(3600));
    client.stop();

    if (fout.is_open()) fout.close();
    return 0;
}
