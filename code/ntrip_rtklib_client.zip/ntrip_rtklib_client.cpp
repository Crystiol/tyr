/*------------------------------------------------------------------------------
* ntrip_client.cpp : simplified NTRIP client based on RTKLIB str2str.c
*
* Reference: RTKLIB app/str2str/str2str.c (master branch)
*            Direct stream_t management with stropen(&str, path, mode)
*
* Copyright (C) 2025, inspired by T. Takasu's RTKLIB
* version : 3.0  exact API from source: stropen returns int, no err param
*-----------------------------------------------------------------------------*/
#include <signal.h>
#include <unistd.h>
#include <iostream>
#include <chrono>
#include <cstring>
#include "rtklib.h"

#define PRGNAME			"Ntrip Browser Qt"
#define NTRIP_HOME		"rtcm-ntrip.org:2101" // caster list home
#define NTRIP_TIMEOUT	10000				// response timeout (ms)
#define MAXSRCTBL		512000				// max source table size (bytes)
#define ENDSRCTBL		"ENDSOURCETABLE"	// end marker of table

static char buff[MAXSRCTBL];

char * getsrctbl(const char* addr)
{
    static int lock=0;
    stream_t str;
    char *p=buff,msg[MAXSTRMSG];
    int len=strlen(ENDSRCTBL);
    unsigned int tick=tickget();

    if (lock) return NULL; else lock=1;

    strinit(&str);

    if (!stropen(&str,STR_NTRIPCLI,STR_MODE_R, addr)) {
        lock=0;
        std::cerr << "stream open error\n";
        return NULL;
    }

    std::cerr << "connecting...\n";

    while(p<buff+MAXSRCTBL-1) {
        int ns=strread(&str,(unsigned char*)p,(buff+MAXSRCTBL-p-1)); *(p+ns)='\0';
        if (p-len-3>buff&&strstr(p-len-3,ENDSRCTBL)) break;
        p+=ns;

        int stat=strstat(&str,msg);

        std::cout << msg << std::endl;

        if (stat<0) break;
        if ((int)(tickget()-tick)>NTRIP_TIMEOUT) {
            std::cerr << "response timeout\n";
            break;
        }
    }
    strclose(&str);
    lock=0;
    return buff;
}

int main(int argc, char **argv) {
    getsrctbl("rtk2go.com");

    strsvr_t strsvr;
    strsvrinit(&strsvr,3);
    strsvr.relayback = 1;
    strsvr.cycle = 10000;

    int opt[7]={10000, 10000, 1000, 32768, 10, 0, 30};
    int strs[4]={7, 2, 0, 0};
    strconv_t *conv[3]={0};
    char cmd[1024] = {""};
    char *cmds[4]={cmd,NULL,NULL,NULL};
    //strncpy(cmd,"",1024);
    char *cmds_periodic[4]={NULL,NULL,NULL,NULL};
    double AntPos[3] = {0.0};

    static char str[4][1024];
    char *paths[4];
    for (int i=0;i<4;i++) paths[i]=str[i];
    strcpy(paths[0], "1041859295@qq.com:none@rtk2go.com:2101/ACAKO::");
    strcpy(paths[1], "/home/tuxu/test.rtcm3::S=12");
    strcpy(paths[2], "");
    strcpy(paths[3], "");

    if (!strsvrstart(&strsvr,opt,strs,paths,conv,cmds,cmds_periodic,AntPos)) {
        std::cout << "strsvrstart: failed" << std::endl;
        return -1;
    }

    while(1);
    return 0;
}