#ifndef TIMING_WHEEL_HPP
#define TIMING_WHEEL_HPP

#include "MPMCRing.hpp"
#include <vector>
// -------------------------- 无锁 TimingWheel（替换原锁实现） --------------------------
/*
  设计目标：
  - 每个槽 slot 使用 MPMC 无锁环（MPMCRing<Entry>），add()/tick() 无需全局锁。
  - tick() 将 last_slot 推进到 now_ms 所在槽，逐槽 drain，避免“集中抖动”。
  - 未到期项轻量回插（重新定位槽）；槽满时短暂自旋并让出，极端下计为 drops。
*/
class TimingWheel {
public:
  struct Entry { int fd; uint64_t expire_ms; };

  // tick_ms: 槽粒度；slots: 槽个数（将提升为2的幂）；slot_cap: 单槽容量
  explicit TimingWheel(uint64_t tick_ms, size_t slots, size_t slot_cap = (1u<<14))
      : tick_ms_(tick_ms), slots_(normalize_pow2(slots)),
        slot_mask_(slots_ - 1), initialized_(false), last_slot_index_(0) {
    slots_q_.reserve(slots_);
    for (size_t i = 0; i < slots_; ++i)
      slots_q_.emplace_back(std::make_unique<MPMCRing<Entry>>(slot_cap));
  }

  // 无锁 add；槽满时短暂自旋，让出 CPU；极端情况下计入 drops（避免阻塞）
  inline void add(int fd, uint64_t expire_ms) {
    Entry e{fd, expire_ms};
    size_t idx = slot_index(expire_ms);
    for (int i = 0; i < 64; ++i) {
      if (slots_q_[idx]->enqueue(e)) return;
      std::this_thread::yield();
    }
    g_metrics.drops.fetch_add(1, std::memory_order_relaxed);
  }

  // 推进到 now_ms 相应槽位，并处理到期/重插
  template <typename F>
  void tick(uint64_t now_ms, F on_timeout) {
    if (!initialized_.load(std::memory_order_acquire)) {
      size_t idx = (now_ms / tick_ms_) & slot_mask_;
      last_slot_index_.store(idx, std::memory_order_release);
      initialized_.store(true, std::memory_order_release);
      return;
    }
    size_t target = (now_ms / tick_ms_) & slot_mask_;
    size_t cur = last_slot_index_.load(std::memory_order_relaxed);
    while (cur != target) {
      drain(cur, now_ms, on_timeout);
      cur = (cur + 1) & slot_mask_;
    }
    last_slot_index_.store(cur, std::memory_order_relaxed);
    drain_light(cur, now_ms, on_timeout); // 可选温和刷新
  }

private:
  template <typename F>
  void drain(size_t idx, uint64_t now_ms, F &on_timeout) {
    Entry e;
    while (slots_q_[idx]->dequeue(e)) {
      if (e.expire_ms <= now_ms) on_timeout(e.fd);
      else add(e.fd, e.expire_ms);
    }
  }
  template <typename F>
  void drain_light(size_t idx, uint64_t now_ms, F &on_timeout) {
    Entry e;
    for (int k = 0; k < 64; ++k) {
      if (!slots_q_[idx]->dequeue(e)) break;
      if (e.expire_ms <= now_ms) on_timeout(e.fd);
      else add(e.fd, e.expire_ms);
    }
  }
  static size_t normalize_pow2(size_t x) { size_t p=1; while(p<x) p<<=1; return p; }
  inline size_t slot_index(uint64_t expire_ms) const {
    return ((expire_ms / tick_ms_) & slot_mask_);
  }

  const uint64_t tick_ms_;
  const size_t   slots_, slot_mask_;
  std::vector<std::unique_ptr<MPMCRing<Entry>>> slots_q_;
  std::atomic<bool>   initialized_;
  std::atomic<size_t> last_slot_index_;
};

#endif
