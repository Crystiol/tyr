#ifndef RING_BUFFER_HPP
#define RING_BUFFER_HPP

#include "BufferPool.hpp"
#include <unistd.h>
#include <vector>

static inline void die(const char *s) {
  perror(s);
  exit(1);
}

// -------------------------- RingBuffer（零拷贝入站） --------------------------
/*
  设计要点：
  - RingBuffer 持有若干 BufferBlock 的链表 head->...->tail
  - 生产者：writable_region()+produce(n)
  - 消费者：peek_bytes/consume
  - 零拷贝：steal_body_after() 对 body 增加引用，随后 consume 掉 ring 中对应字节
*/
class RingBuffer {
public:
  RingBuffer(BufferPool &pool)
      : pool_(pool), head_(nullptr), tail_(nullptr), head_off_(0), tail_off_(0) {
    append_block();
  }
  ~RingBuffer() {
    BufferBlock *cur = head_;
    while (cur) {
      BufferBlock *nxt = cur->next;
      pool_.release_ref(cur);
      cur = nxt;
    }
    head_ = tail_ = nullptr;
  }

  // 返回可写区域（不跨块）
  iovec writable_region() {
    ensure_tail();
    return iovec{tail_->data + tail_off_, BUFFER_BLOCK_SIZE - tail_off_ - 1};
  }

  // 生产者在写入后调用，n 为写入字节数
  void produce(size_t n) {
    tail_off_ += n;
    if (tail_off_ >= BUFFER_BLOCK_SIZE - 1) {
      append_block();
      tail_off_ = 0;
    }
  }

  // 从 head 开始 peek 最多 n 字节到 dst，但不消费 ring
  size_t peek_bytes(uint8_t *dst, size_t n) {
    if (!head_)
      return 0;
    size_t copied = 0;
    BufferBlock *cur = head_;
    size_t off = head_off_;
    size_t remain = n;
    while (remain > 0 && cur) {
      size_t avail = (cur == tail_) ? (tail_off_ - off) : (BUFFER_BLOCK_SIZE - off);
      if (avail == 0)
        break;
      size_t take = std::min(avail, remain);
      memcpy(dst + copied, cur->data + off, take);
      copied += take;
      remain -= take;
      off += take;
      if (off >= BUFFER_BLOCK_SIZE) {
        cur = cur->next;
        off = 0;
      }
    }
    return copied;
  }

  // 消费 n 字节，并释放完整消费掉的 blocks 的引用
  void consume(size_t n) {
    size_t remain = n;
    while (remain > 0 && head_) {
      size_t avail = (head_ == tail_) ? (tail_off_ - head_off_) : (BUFFER_BLOCK_SIZE - head_off_);
      if (avail > remain) {
        head_off_ += remain;
        return;
      }
      remain -= avail;
      BufferBlock *old = head_;
      head_ = old->next;
      pool_.release_ref(old);
      head_off_ = 0;
      if (!head_) {
        tail_ = nullptr;
        tail_off_ = 0;
        break;
      }
    }
  }

  // 可读字节数（跨块计算）
  size_t readable_bytes() const {
    if (!head_)
      return 0;
    if (head_ == tail_)
      return (tail_off_ >= head_off_) ? (tail_off_ - head_off_) : 0;
    size_t cnt = 0;
    BufferBlock *cur = head_;
    size_t off = head_off_;
    while (cur) {
      if (cur == tail_) {
        cnt += tail_off_ - off;
        break;
      }
      cnt += BUFFER_BLOCK_SIZE - off;
      cur = cur->next;
      off = 0;
    }
    return cnt;
  }

  // Steal body：在已 consume header 的前提下，为 body 创建引用列表 out（零拷贝）
  struct StealEntry {
    BufferBlock *blk;
    size_t offset;
    size_t len;
  };
  bool steal_body_after(size_t header_len, size_t body_len, std::vector<StealEntry> &out) {
    if (readable_bytes() < header_len + body_len)
      return false;
    BufferBlock *cur = head_;
    size_t off = head_off_;
    size_t skip = header_len;
    while (skip > 0 && cur) {
      size_t avail = (cur == tail_) ? (tail_off_ - off) : (BUFFER_BLOCK_SIZE - off);
      if (avail > skip) {
        off += skip;
        skip = 0;
        break;
      }
      skip -= avail;
      cur = cur->next;
      off = 0;
    }
    size_t remain = body_len;
    std::vector<BufferBlock *> to_retain;
    while (remain > 0 && cur) {
      size_t avail = (cur == tail_) ? (tail_off_ - off) : (BUFFER_BLOCK_SIZE - off);
      size_t take = std::min(avail, remain);
      out.push_back({cur, off, take});
      if (to_retain.empty() || to_retain.back() != cur)
        to_retain.push_back(cur);
      remain -= take;
      off += take;
      if (off >= BUFFER_BLOCK_SIZE) {
        cur = cur->next;
        off = 0;
      }
    }
    for (BufferBlock *b : to_retain) pool_.retain(b);
    consume(header_len + body_len); // ring 前进（释放 ring 持有的引用）
    return true;
  }

private:
  BufferPool &pool_;
  BufferBlock *head_;
  BufferBlock *tail_;
  size_t head_off_, tail_off_;

  void append_block() {
    BufferBlock *b = pool_.acquire();
    if (!b)
      die("BufferPool exhausted");
    b->next = nullptr;
    if (!head_) {
      head_ = tail_ = b;
      head_off_ = tail_off_ = 0;
    } else {
      tail_->next = b;
      tail_ = b;
    }
  }
  void ensure_tail() {
    if (!tail_) {
      append_block();
      return;
    }
    if (tail_off_ >= BUFFER_BLOCK_SIZE - 1) {
      append_block();
      tail_off_ = 0;
    }
  }
};

#endif
