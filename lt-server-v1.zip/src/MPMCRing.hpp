#ifndef MPMCRING_HPP
#define MPMCRING_HPP

#include <cassert>
#include <vector>
#include <memory>

// -------------------------- 简单 MPMC 环（用于内部队列） --------------------------
template <typename T> class MPMCRing {
public:
  explicit MPMCRing(size_t cap_pow2) : size_(cap_pow2), mask_(cap_pow2 - 1) {
    // cap_pow2 必须是 2 的幂（为了 & 取模）
    assert((cap_pow2 & (cap_pow2 - 1)) == 0);
    entries_.resize(size_);
    for (size_t i = 0; i < size_; ++i) {
      entries_.emplace_back(std::make_unique<Entry>(i));
    }
    head_.store(0);
    tail_.store(0);
  }
  bool enqueue(const T &v) {
    Entry *e;
    size_t pos = head_.load(std::memory_order_relaxed);
    for (;;) {
      e = entries_[pos & mask_].get();
      size_t seq = e->seq.load(std::memory_order_acquire);
      intptr_t dif = (intptr_t)seq - (intptr_t)pos;
      if (dif == 0) {
        if (head_.compare_exchange_weak(pos, pos + 1)) {
          e->val = v;
          e->seq.store(pos + 1, std::memory_order_release);
          return true;
        }
      } else if (dif < 0) {
        return false;
      } else {
        pos = head_.load(std::memory_order_relaxed);
      }
    }
  }
  bool dequeue(T &out) {
    Entry *e;
    size_t pos = tail_.load(std::memory_order_relaxed);
    for (;;) {
      e = entries_[pos & mask_].get();
      size_t seq = e->seq.load(std::memory_order_acquire);
      intptr_t dif = (intptr_t)seq - (intptr_t)(pos + 1);
      if (dif == 0) {
        if (tail_.compare_exchange_weak(pos, pos + 1)) {
          out = e->val;
          e->seq.store(pos + size_, std::memory_order_release);
          return true;
        }
      } else if (dif < 0) {
        return false;
      } else {
        pos = tail_.load(std::memory_order_relaxed);
      }
    }
  }

private:
  struct Entry {
    std::atomic<size_t> seq;
    T val;
    Entry(size_t s) : seq(s), val() {}
  };

  std::vector<std::unique_ptr<Entry>> entries_;
  size_t size_, mask_;
  alignas(64) std::atomic<size_t> head_, tail_;
};

#endif
