#ifndef BUFFER_POOL_HPP
#define BUFFER_POOL_HPP

#include "ServerConfig.h"
#include <vector>
#include <atomic>

// -------------------------- BufferPool（固定大小块，带引用计数） --------------------------
/*
  设计要点：
  - BufferBlock 大小固定（BUFFER_BLOCK_SIZE）
  - 内存以数组方式预分配，避免频繁 new/free
  - 使用无锁 freelist（单向链表 + CAS），acquire/return 都是无锁的
  - refcount 用于多个消费者共享同一 block（零拷贝传递）
*/
struct BufferBlock {
  std::atomic<int> refcount;
  BufferBlock *next;
  alignas(64) uint8_t data[BUFFER_BLOCK_SIZE];
};

class BufferPool {
public:
  explicit BufferPool(size_t total_blocks) {
    storage_.reserve(total_blocks);
    for (size_t i = 0; i < total_blocks; ++i)
      storage_.emplace_back(std::make_unique<BufferBlock>());

    // 构建 freelist
    for (size_t i = 0; i + 1 < total_blocks; ++i)
      storage_[i]->next = storage_[i + 1].get();
    storage_.back()->next = nullptr;
    freelist_.store(storage_[0].get(), std::memory_order_relaxed);
  }

  // 返回一个持有 refcount=1 的块，失败返回 nullptr
  BufferBlock *acquire() {
    BufferBlock* h = freelist_.load(std::memory_order_acquire);
    while (h) {
      BufferBlock* nxt = h->next;
      if (freelist_.compare_exchange_weak(h, nxt,
                                         std::memory_order_acq_rel)) {
        h->next = nullptr;
        h->refcount.store(1, std::memory_order_release);
        return h;
                                         }
    }
    return nullptr;
  }

  // 增加引用
  void retain(BufferBlock *b) { b->refcount.fetch_add(1, std::memory_order_acq_rel); }

  // 释放引用：当 refcount 从 1 -> 0 时，回收到 freelist
  void release_ref(BufferBlock *b) {
    int prev = b->refcount.fetch_sub(1, std::memory_order_acq_rel);
    if (prev == 1) {
      BufferBlock* head = freelist_.load(std::memory_order_relaxed);
      do {
        b->next = head;
      } while (!freelist_.compare_exchange_weak(
          head, b, std::memory_order_release, std::memory_order_relaxed));
    }
  }

private:
  std::vector<std::unique_ptr<BufferBlock>> storage_;
  std::atomic<BufferBlock *> freelist_;
};

#endif

