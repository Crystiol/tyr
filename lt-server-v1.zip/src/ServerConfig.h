//
// Created by tuxu on 25-8-19.
//

#ifndef SERVERCONFIG_H
#define SERVERCONFIG_H

#include <atomic>

// -------------------------- 可配置参数 --------------------------
static const size_t BUFFER_BLOCK_SIZE = 4096;
static const size_t DEFAULT_BLOCKS_PER_CPU = 64 * 1024; // 根据内存/连接量调节
static const size_t OUT_RING_CAP = 1024;
static const uint64_t DEFAULT_IDLE_MS = 60 * 1000;
static const uint64_t DEFAULT_ACTIVE_MS = 5 * 60 * 1000;

struct Metrics {
    std::atomic<uint64_t> accepted{0}, closed{0}, rx_bytes{0}, tx_bytes{0},
        rx_pkts{0}, tx_pkts{0}, drops{0}, parse_errors{0}, timeouts{0};
};

extern struct Metrics g_metrics;

#endif //SERVERCONFIG_H
